"""Feature building and scoring for the Loan Default Prediction model."""
from pathlib import Path
import numpy as np
import pandas as pd
import joblib

MODEL_PATH = Path(__file__).parent / "loan_default_model.joblib"


def load_bundle(path=MODEL_PATH):
    return joblib.load(path)


def category_levels(bundle):
    """Dropdown options for the four categorical fields, read from the trained encoder."""
    pre = bundle["pipeline"].named_steps["pre"]
    cats = pre.named_transformers_["cat"].categories_
    return dict(zip(["contract_type", "province", "group", "history_type"], [list(c) for c in cats]))


def make_features(p):
    """Turn one borrower (a dict) into the 30 model features. Mirrors the notebook's build_features()."""
    past = [float(x) for x in p["past_months"]]               # Jul..Dec 2012, oldest first
    arr = np.array(past)
    late = arr > 0
    age = p["age"]
    study, career = p.get("years_of_study"), p.get("total_career_years")
    has_info = int(study is not None)
    if study is not None and study > age - 4:   study = None   # same domain rules as Stage 2
    if career is not None and career > age - 14: career = None
    expense = float(p["monthly_expense"])
    reg = pd.Timestamp(p["registration_date"])
    row = {
        "years_of_study": np.nan if study is None else study,
        "family_size": min(p["family_size"], 10),
        "loan_amount": p["loan_amount"],
        "total_career_years": np.nan if career is None else career,
        "contract_type": p["contract_type"], "is_male": p["is_male"], "province": p["province"],
        "age": age, "group": p["group"], "history_type": p["history_type"],
        "has_edu_career_info": has_info,
        **{f"past_m{i+1}": past[i] for i in range(6)},
        "past_max": arr.max(), "past_mean": arr.mean(), "past_sum": arr.sum(), "past_last": arr[5],
        "past_trend": arr[3:].mean() - arr[:3].mean(),
        "past_months_late": int(late.sum()), "past_months_ge2": int((arr >= 2).sum()),
        "months_since_late": int(np.argmax(late[::-1])) if late.any() else 6,
        "log_monthly_expense": np.log1p(expense), "expense_zero": int(expense == 0),
        "log_loan_to_expense": np.log1p(p["loan_amount"] / expense) if expense > 0 else np.nan,
        "tenure_months": (pd.Timestamp("2013-01-01") - reg).days / 30.4, "reg_month": reg.month,
    }
    return pd.DataFrame([row])


def score(bundle, borrower):
    """Return risk score, band and decision for one borrower dict."""
    s = float(bundle["pipeline"].predict_proba(make_features(borrower))[:, 1][0])
    cut = bundle["band_cutoffs"]
    band = "High" if s >= cut["high"] else "Medium" if s >= cut["medium"] else "Low"
    return {"risk_score": s, "risk_band": band, "flag_for_review": s >= bundle["threshold_cost"]}
