import datetime as dt
import streamlit as st
from scoring import load_bundle, category_levels, score

st.set_page_config(page_title="Loan Default Risk", page_icon="💳", layout="centered")


@st.cache_resource
def get_bundle():
    return load_bundle()


bundle = get_bundle()
levels = category_levels(bundle)

st.title("Loan Default Risk Scorer")
st.caption("Predicts the chance that a borrower reaches 3 or more missed payments in the next 11 months. "
           f"Model: {bundle['model_name']}.")

with st.form("borrower"):
    st.subheader("Borrower profile")
    c1, c2, c3 = st.columns(3)
    age = c1.number_input("Age", 18, 80, 33)
    is_male = c2.selectbox("Gender", [1.0, 0.0], format_func=lambda v: "Male" if v == 1 else "Female")
    family = c3.number_input("Family size", 0, 10, 0)
    c1, c2 = st.columns(2)
    loan = c1.number_input("Loan amount", 50000, 400000, 150000, step=1000)
    expense = c2.number_input("Monthly expense", 0, 1_500_000, 15000, step=500)
    c1, c2, c3, c4 = st.columns(4)
    contract = c1.selectbox("Contract type", levels["contract_type"])
    province = c2.selectbox("Province", levels["province"])
    group = c3.selectbox("Group", levels["group"])
    history = c4.selectbox("History type", levels["history_type"])
    reg = st.date_input("Registration date", dt.date(2012, 6, 1), min_value=dt.date(2012, 1, 1), max_value=dt.date(2012, 12, 31))
    has_info = st.checkbox("Education and career details are available")
    study = career = None
    if has_info:
        c1, c2 = st.columns(2)
        study = c1.number_input("Years of study", 0, 60, 4)
        career = c2.number_input("Total career years", 0, 60, 4)

    st.subheader("Repayment history (overdue-instalment counter per month)")
    months = ["Jul 2012", "Aug 2012", "Sep 2012", "Oct 2012", "Nov 2012", "Dec 2012"]
    cols = st.columns(6)
    past = [col.number_input(m, 0, 12, 0, key=m) for col, m in zip(cols, months)]
    go = st.form_submit_button("Score borrower", type="primary")

if go:
    res = score(bundle, {
        "age": age, "is_male": is_male, "family_size": family, "loan_amount": loan, "monthly_expense": expense,
        "contract_type": contract, "province": province, "group": group, "history_type": history,
        "registration_date": reg, "years_of_study": study, "total_career_years": career, "past_months": past})
    st.divider()
    a, b, c = st.columns(3)
    a.metric("Risk score", f"{res['risk_score']:.1%}")
    b.metric("Risk band", res["risk_band"])
    c.metric("Decision", "Review / decline" if res["flag_for_review"] else "Approve")
    st.progress(min(res["risk_score"], 1.0))
    st.caption("The score ranks borrowers by risk. The decision threshold assumes a missed defaulter costs 5 times "
               "a wrongly flagged borrower; change it to match your lending policy.")
