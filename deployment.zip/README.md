# Loan Default Risk Scorer: deployment package

| File | Purpose |
|---|---|
| `app.py` | Streamlit web app (form, risk score, band, decision) |
| `scoring.py` | Feature building and scoring; the same logic as the notebook |
| `loan_default_model.joblib` | Trained LightGBM pipeline with thresholds |
| `requirements.txt` | Pinned libraries (must match the versions the model was trained with) |

## Run locally
```
pip install -r requirements.txt
streamlit run app.py
```
Open http://localhost:8501.

## Host free on Streamlit Community Cloud
1. Create a GitHub repository and upload these four files (the model file is under 1 MB).
2. Go to share.streamlit.io, sign in with GitHub, choose New app.
3. Select the repository, branch `main`, main file `app.py`, then Deploy.
4. Share the public URL it gives you.

## Use the model from your own Python code
```python
from scoring import load_bundle, score
bundle = load_bundle()
print(score(bundle, {...}))   # see app.py for the required fields
```
